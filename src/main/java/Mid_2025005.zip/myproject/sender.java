/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myproject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


/**
 *
 * @author santoosa
 */
public class sender {
   
    
    public static void main(String[] agrs)throws Exception{
        
           
    ServerSocket ss= new ServerSocket(7777);
     Socket s=ss.accept();
     BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
    String sc=br.readLine();
    OutputStream out=s.getOutputStream();
    DataOutputStream dout=new DataOutputStream(out);
    dout.writeUTF(sc);
    dout.flush();
    s.close();
    ss.close();
    
    
}
   
    
    
}



