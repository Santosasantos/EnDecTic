/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myproject;

import java.awt.List;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author santoosa
 */
public class RSA_code {
    static BigInteger p,q,n,phi_n,Gcd,ce,d;
    public static void main(String[] args) {
        
         Scanner sc=new Scanner(System.in);
            String s0=sc.nextLine(); //reading the String input
        
   // GUIofEnDecTic g=new GUIofEnDecTic();
     Random r1=new Random(System.currentTimeMillis());
    
     Random r3=new Random(System.currentTimeMillis());
     
     int e=2;//Encryption key assuming initially as 2 it will change
     
     ///Prime p and q assuming 64 bit random value
      p=BigInteger.probablePrime(64, r1);
      q=BigInteger.probablePrime(64, r1);
     
     
      n=p.multiply(q);///n=p*q;
     
     phi_n=(p.subtract(new BigInteger("1"))).multiply(q.subtract(new BigInteger("1"))); //phi_n=(p-1)*(q-1)
     
     //our Encryption key should be corelative prime of phi_n
     while(true){
          Gcd=phi_n.gcd(new BigInteger(""+e));
         if(Gcd.equals(BigInteger.ONE)){
             break;
         }
         e++;
     }
      ce=new BigInteger(""+e); //cipher key
     
      d=ce.modInverse(phi_n);//decipher key=(cipherkey)^-1 mod phi_n
     
    //String s0="hello,What's up ? what about you?Do you need $dollar";
     
     //StringBuilder st=new StringBuilder();
     
     byte[] bytes=s0.getBytes();
     Encryption(s0,bytes,ce,n,r3);
     Decryption(s0,bytes,ce,d,n);
    
        
        
        
        
        
        
}
    static void Encryption(String s,byte[] bt,BigInteger c,BigInteger nn,Random rr){
        ArrayList l=new ArrayList();
       
     for(int i=0;i<s.length();i++){
         int ascii=bt[i];
         BigInteger val=new BigInteger(""+ascii);
         BigInteger cipherval=val.modPow(c, nn); 
         System.out.print(cipherval);
                          
     }
     
      
        
        long newl=Math.ceilDiv((s.length()*8), 15);
        for(int i=0;i<(15*newl)-(s.length()*8);i++){
            l.add(rr.nextInt(10));
        }
        for(Object i:l){
            System.out.print(i);
        }
        System.out.println("");
    }
    static void Decryption(String s,byte[] bt,BigInteger c,BigInteger d,BigInteger nn){
                StringBuilder st=new StringBuilder();
     for(int i=0;i<s.length();i++){
         int ascii=bt[i];
         BigInteger val=new BigInteger(""+ascii);
         BigInteger cipherval=val.modPow(c, nn);
        
        
        BigInteger plain=cipherval.modPow(d, nn);
        int i_plain=plain.intValue();
        st.append(Character.toString((char)i_plain));
           
     }
     
        System.out.println(st);
    }
}
